import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormControl, FormBuilder, FormControlName } from '@angular/forms';
import { Router } from '@angular/router';
import { AdmissionService } from '../admission.service';
import { Admission } from '../models/admissionForm.model';
import * as moment from 'moment';
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';

export interface Section{
  
  viewValue: string;
}
export interface Class{
  
  viewClass:number;
}
export interface bloodGroups{

  viewValue:string;
}
@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css'],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: {showError: true}
  }]
})

export class StudentFormComponent implements OnInit {
  // registerForm: FormGroup;
//   submitted = false;
  admission:Admission[];
  
 
  sections: Section[] = [
    {viewValue: 'A'},
    { viewValue: 'B'},
    {viewValue: 'C'},
    {viewValue: 'D'}
  ];
  Classes: Class[] = [
    { viewClass: 1},
    { viewClass: 2},
    { viewClass: 3},
    { viewClass: 4},
    { viewClass: 5},
    { viewClass: 6},
    { viewClass: 7},
    { viewClass: 8},
    { viewClass: 9},
    { viewClass: 10}
  ];
 blood: bloodGroups[] = [
    { viewValue:'A+'},
    { viewValue:'A-'},
    { viewValue:'B+'},
    { viewValue:'B-'},
    { viewValue:'O+'},
    { viewValue:'O-'},
    { viewValue:'AB+'},
    { viewValue:'AB-'}
  ];
  studentForm: FormGroup;
  parentsForm: FormGroup;
editForm:FormGroup

minDate = new Date(1981,0,1).toISOString().substring(0, 10);
maxDate = new Date().toISOString().substring(0, 10);
  constructor(private formBuilder: FormBuilder,private router:Router,private adminService:AdmissionService) { }
 

  date:any
  ngOnInit(  
  ) {
  
    this.studentForm = this.formBuilder.group({
      id:[''],
      firstName: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      lastName: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      gender: ['', Validators.required],
      dateOfBirth: [this.date, Validators.required],
      classes:['', Validators.required],
      section:['', Validators.required],
      bloodGroup:[''],
      address: ['', Validators.required],
    
      phoneNumber: ['',[ Validators.required,Validators.pattern('[6-9]\\d{9}')]],
      email: ['',Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]
     
    });
    this.parentsForm = this.formBuilder.group({
     
      fatherFullName: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      motherFullName: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      fatherOccupation: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      motherOccupation: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      contactNum: ['',[Validators.required,Validators.pattern('[0-9]\\d{9}')]],
      email: ['',Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]
    });
    this.editForm = this.formBuilder.group({
     
      firstName: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      lastName: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      gender: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      // mOcc: ['',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]],
      // income: ['',[Validators.required,Validators.pattern('[6-9]\\d{9}')]],
    });
      this.adminService.getAdmission()
      .subscribe( data => {
        this.admission = data;
      });
    
    
      let userId = localStorage.getItem("id");
      if(!userId) {
       
        // this.router.navigate(['list-user']);
        return;
      }

    this.adminService.getUserById(+userId)
      .subscribe( data => {
        this.editForm.setValue(data);
      });
  }

 hasError = (controlName: string, errorName: string) =>{
    return this.studentForm.controls[controlName].hasError(errorName);
  }
  hasError1 = (controlName: string, errorName: string) =>{
    return this.parentsForm.controls[controlName].hasError(errorName);
  }
   createRegister() {
    if (this.studentForm.valid) {
      this.adminService.createAdmission(this.studentForm.value)
      .subscribe( data =>{
      });
    }
    console.log(this.studentForm.value)
  }
createRegister1() {
    if (this.parentsForm.valid) {
      this.adminService.createAdmission(this.parentsForm.value)
      .subscribe( data => {this.admission=data
      });
    }
    console.log(this.parentsForm.value)
  }
  editUser(user: Admission): void {
    localStorage.removeItem("editUserId");
    localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['edit-user']);
  };
}

