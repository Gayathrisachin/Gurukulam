import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormControl, FormBuilder, FormControlName } from '@angular/forms';
import { Router } from '@angular/router';
import { AdmissionService } from '../admission.service';
import { Admission } from '../models/admissionForm.model';
import * as moment from 'moment';

export interface Section{
  // value: string;
  viewValue: string;
}
export interface Class{
  // value:number;
  viewClass:number;
}
export interface bloodGroups{
  // value:number;
  viewValue:string;
}
@Component({
  selector: 'app-student-admission',
  templateUrl: './student-admission.component.html',
  styleUrls: ['./student-admission.component.css']
})

export class  StudentAdmissionComponent implements OnInit {
  // registerForm: FormGroup;
  submitted = false;
  admission:Admission[];
  
 
  sections: Section[] = [
    {viewValue: 'A'},
    { viewValue: 'B'},
    {viewValue: 'C'},
    {viewValue: 'D'}
  ];
  Classes: Class[] = [
    { viewClass: 1},
    { viewClass: 2},
    { viewClass: 3},
    { viewClass: 4},
    { viewClass: 5},
    { viewClass: 6},
    { viewClass: 7},
    { viewClass: 8},
    { viewClass: 9},
    { viewClass: 10}
  ];
 blood: bloodGroups[] = [
    { viewValue:'A+'},
    { viewValue:'A-'},
    { viewValue:'B+'},
    { viewValue:'B-'},
    { viewValue:'O+'},
    { viewValue:'O-'},
    { viewValue:'AB+'},
    { viewValue:'AB-'}
  ];

  isOptional = false;

minDate = new Date().toISOString().substring(0, 10);
// date:any
studentForm =new FormGroup({

    firstName: new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]),
    lastName:new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$')]),
    address:new FormControl('', Validators.required),
   date:new FormControl(this.minDate,Validators.required),
    gender:new FormControl('', Validators.required),
    selectedValue:new FormControl('', Validators.required),
    selectedClass:new FormControl('', Validators.required),
    bloodGroup:new FormControl('', Validators.required),
    email: new FormControl('',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')]),
    phone: new FormControl('',[ Validators.required,Validators.pattern('[6-9]\\d{9}')])
  });
// parentsForm =new FormGroup({
//     fName: new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]),
//     mName: new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]),
//     fOcc: new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]),
//     mOcc: new FormControl('',[Validators.required,Validators.pattern('^[a-zA-Z ]*$'),Validators.maxLength(20)]),
//     phone: new FormControl('',[ Validators.required,Validators.pattern('[6-9]\\d{9}')])
//   });

  constructor(private formBuilder: FormBuilder,private router:Router,private adminService:AdmissionService) { }
 
  // maxDate = new Date(2019,0,1);
  // date:any
  ngOnInit() {
     
      this.adminService.getAdmission()
      .subscribe( data => {
        this.admission = data;
      })
  }
 hasError = (controlName: string, errorName: string) =>{
    return this.studentForm.controls[controlName].hasError(errorName);
  }
 
  public createRegister = (registerFormValue) => {
    if (this.studentForm.valid) {
      this.adminService.createAdmission(this.studentForm.value)
      .subscribe( data => {this.router.navigate(['home'])
      });
    }
  }
}

