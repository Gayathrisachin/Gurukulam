

export interface Admission{
  
id:number
   firstName:string
   lastName:string
  address:string
    gender:string
//    date:Date
phoneNumber:number
section:string
   classes:number
fatherFullName:string
motherFullName:string
motherOccupation:string
fatherOccupation:string
   income:number
}