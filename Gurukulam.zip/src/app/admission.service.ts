import { Injectable } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Admission } from './models/admissionForm.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdmissionService {
  url:string='http://192.168.0.198:8081/admission';

  constructor(private http:HttpClient) { }
  getAdmission():Observable<Admission[]>{
    return this.http.get<Admission[]>(this.url);
      }
createAdmission(data:Admission):Observable<Admission[]>{
  return this.http.post<Admission[]>(this.url+'/addstudent',data)
}
getUserById(id: number) {
  return this.http.get<Admission>(this.url + '/' + id);
}

  
}
